<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="{{url('admin/login')}}" method="post">
      <input type="text" name="username" value="">
      <input type="password" name="password" value="">
      <button type="submit" name="button">SUBMIT</button>
    </form>
  </body>
</html>
