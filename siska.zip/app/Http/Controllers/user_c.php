<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class user_c extends Controller
{
  function test(){
    return "OK";
  }
}
