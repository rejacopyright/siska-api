<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class siswa extends Model
{
  protected $table = 'siswa';
  protected $guarded = [];
  // PARENT
  function kelas(){
    return $this->belongsTo('App\kelas', 'kelas_id', 'kelas_id');
  }
}
